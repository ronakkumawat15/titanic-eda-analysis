# Titanic Exploratory Data Analysis (EDA)

## Overview
This project performs Exploratory Data Analysis (EDA) on the Titanic dataset to understand patterns and relationships between passenger characteristics and survival.

## Dataset
titanic.csv

## EDA Steps
1. Load dataset
2. Inspect data structure and missing values
3. Handle missing values
4. Perform statistical summary
5. Visualize distributions
6. Detect outliers
7. Analyze correlations

## Tools Used
Python
Pandas
NumPy
Seaborn
Matplotlib

## Files in Project
titanic.csv - Dataset
eda_analysis.py - Python script for EDA
README.md - Project description
