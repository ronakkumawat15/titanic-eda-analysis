import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

# Load dataset
df = pd.read_csv("titanic.csv")

print("Dataset Shape:", df.shape)
print("\nData Types:\n", df.dtypes)
print("\nMissing Values:\n", df.isnull().sum())

# Summary statistics
print("\nSummary Statistics:\n", df.describe(include='all'))

# Handle missing values
df['Age'].fillna(df['Age'].median(), inplace=True)
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)

# Age distribution
plt.figure(figsize=(8,5))
sns.histplot(df['Age'], bins=20, kde=True)
plt.title("Age Distribution")
plt.show()

# Survival by Gender
plt.figure(figsize=(8,5))
sns.countplot(x='Sex', hue='Survived', data=df)
plt.title("Survival by Gender")
plt.show()

# Correlation heatmap
plt.figure(figsize=(8,5))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Matrix")
plt.show()

# Fare outliers
plt.figure(figsize=(8,4))
sns.boxplot(x=df['Fare'])
plt.title("Fare Outliers")
plt.show()

# Z-score outlier detection
z_scores = np.abs(stats.zscore(df['Fare']))
outliers = df[z_scores > 3]
print("Number of Fare Outliers:", len(outliers))

# Pairplot
sns.pairplot(df[['Age','Fare','Parch','Survived']], hue='Survived')
plt.show()
